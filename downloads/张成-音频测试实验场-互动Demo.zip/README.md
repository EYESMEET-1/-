# 战斗音频测试实验场

这是一个用于游戏音频功能、混音、空间定位、兼容性与性能风险验证的本地测试实验场。项目不依赖游戏引擎，使用 Canvas 2D 和 Web Audio API 构建。

## 运行

```powershell
& "C:\Users\20989\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" server.js
```

打开 `http://127.0.0.1:4173`。

## 自动测试

```powershell
& "C:\Users\20989\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" tests\smoke-test.js
```

测试结果与截图写入 `evidence/`。

## 测试范围

- 功能：事件触发、重复触发、死亡与重生。
- 混音：Master、Music、SFX、Voice 分轨与语音压低BGM。
- 空间：左右声像、距离衰减与声像反转故障。
- 稳定性：延迟、重复播放、BGM切换断点与静音泄漏。
- 性能：活跃声部数量、实时峰值电平和持续渲染。
- 兼容：桌面与移动端布局，Chrome 浏览器自动验证。

## 故障注入

页面可手动开启或通过 `window.__AUDIO_LAB__.setFault(name, enabled)` 开启。自动测试使用同一接口验证测试有效性。

可用故障：

- `latency`
- `duplicate`
- `bgmGap`
- `duckStuck`
- `panInvert`
- `voiceLeak`
